//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 1992-2008 Andras Varga
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//

#ifdef _MSC_VER
#pragma warning(disable:4786)
#endif

#include "ClientApp.h"
#include "color.h"
#include "RoutingTable.h"

/**
 * Generates Interests for the network.
 */

ClientApp::ClientApp()
{
    generatePacket = NULL;
    ChangeInterestRate=NULL;
    datapackets=NULL;
    AS=0;
    nid_c=0;
    RateChangePeriod=0;
    GetCounter=0;
    sizes.clear();
}

ClientApp::~ClientApp()
{
    cancelAndDelete(generatePacket);
    cancelAndDelete(ChangeInterestRate);
    cancelAndDelete(datapackets);
    GetCounter = 0;
}


Define_Module(ClientApp);

void ClientApp::initialize(int stage)
{
    if(stage==0){
    nid_c = par("nid");
    RateChangePeriod = &par("RateChangePeriod"); //�������øı䷢Get����Ƶ�ʣ��������ò����Ƿ�ı�
    InterestsPerSecond = &par("InterestsPerSecond");  // volatile parameter ��̬�Ĳ�����parǰ��Ҫ�ӵ�ַ��
    Zipf_alpha=par("Zipf_alpha");
    NumContent = par("NumContent");
    AS=par("AS");

    ChangeRate = par("ChangeRate");
    Active = par("Active");

    //ֻ����RoutingTable���ȡSID�����ݴ�С��ӳ��
    cModule * routingmodule = getParentModule()->getSubmodule("RoutingTable");
    RoutingTable * rt = dynamic_cast<RoutingTable*>(routingmodule);
    sizes = rt->content_sizes;

    WATCH(GetCounter);
    WATCH(nid_c); //ͼ�ν�����Կ���

    if(InterestsPerSecond!=0 && Active){
    packets_interval = exponential(1.0/InterestsPerSecond->doubleValue());
    //packets_interval = uniform(1./20,1./InterestsPerSecond); //InterestsPerSecond <20
    //packets_interval = 1./InterestsPerSecond;

    generatePacket = new cMessage("getmsg");
    scheduleAt(simTime()+packets_interval, generatePacket);
    }
    else{
           if (ev.isGUI()) bubble("The client is not active or the InterestPerSeond is zero.");
    }

    if (ChangeRate)
    {
        ChangeInterestRate = new cMessage("changerate");
        scheduleAt(simTime()+RateChangePeriod->doubleValue(), ChangeInterestRate);
    }
    else
        bubble("The arg 'InterestsPerSecond' is not changed.");
    }
}

void ClientApp::handleMessage(cMessage *msg)
{
    cModule * routingmodule=getParentModule()->getSubmodule("RoutingTable");
    RoutingTable * rt = dynamic_cast<RoutingTable*>(routingmodule);
    std::map<uint32_t,uint32_t> ATR = rt->AStoRMnid;
    int RMNid=ATR[AS];

    if(Active){
    if (msg == generatePacket)
    {
        // Sending packet
        //char pkname[40];
        //sid zipf
        uint32_t sid = zipf(Zipf_alpha,NumContent);  //sid can not be zero

        //content_size geometrically distribution
        //unsigned long content_size=intuniform(10,1000);
        uint32_t content_size = sizes[sid];
        //���ݴ�С��sid�ҹ���

        //sprintf(pkname,"get-%ld-sid-%d-size-%ld",GetCounter++,sid,content_size);
        //std::vector<uint32_t> pids;

        Interest *pk = new Interest;
        pk->setKind(GET);
        pk->setSid(sid);
        pk->setContent_size(content_size);
        pk->setNid_c(nid_c);
        pk->setNid_incoming_br(RMNid);
        pk->setCache_node(0);
        //pk->setPid(pids);
        pk->setByteLength(28);//7*4 + pid.size()*4
        pk->setQoS_level(0);
        send(pk,"cleint_port");
        scheduleAt(simTime()+packets_interval, generatePacket);
    }// generatePacket
    else if(msg == ChangeInterestRate)
    {
        if(InterestsPerSecond!=0){
            packets_interval = exponential(1.0/InterestsPerSecond->doubleValue());
            //packets_interval = uniform(1./20,1./InterestsPerSecond);
            //packets_interval = 1./InterestsPerSecond;
        }
        scheduleAt(simTime()+RateChangePeriod->doubleValue(), ChangeInterestRate);
    }// changeInterestRate
    else
        {
          short type=msg->getKind();
          if(type!=GET)
              error("wrong packets type.");
          delete msg;
        }
    }//if active
}


bool ClientApp::is_active()
{
    return Active;
}
bool ClientApp::is_ChangeRate()
{
    return ChangeRate;
}

unsigned int ClientApp::zipf(double alpha, unsigned int n)
{
    static bool first = true;      // Static first time flag
    static double c = 0;          // Normalization constant
    int i=0;    // Loop counter
    double z=0;  // Uniform random number (0 < z < 1)
    double sum_prob=0;  // Sum of probabilities
    double zipf_value=0;  // Computed exponential value to be returned

    if (first == true)
     {
      for (i=1; i<=n; i++)
         c = c + (1.0 / pow((double) i, alpha));
       c = 1.0 / c;
       first = false;
     }

    while(z==0 || z==1)
    z=uniform(0,1,nid_c); //use nid as rng

    for(i=1;i<=n;i++)
    {
        sum_prob = sum_prob + c /pow((double) i, alpha);
        if(sum_prob >=z)
        {
             zipf_value=i;
             break;
        }
    }
    assert((zipf_value >=1) && (zipf_value <= n));
    return (int) zipf_value;  //������0
}

void ClientApp::finish()
{
}

