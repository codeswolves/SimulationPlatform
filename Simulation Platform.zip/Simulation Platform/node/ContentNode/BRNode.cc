//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 1992-2008 Andras Varga
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//
#include "BRNode.h"
#include "color.h"
#include "RoutingTable.h"

/**
 * A module which is border router.
 */


BRNode::BRNode()
{
 border=true;
 nid_br=0;
 AS=0;
 cachespace=0;
 avaliable_cache_space=0;
 MornitoringPeriod=0;
 networkStates=NULL;
 EnableCache=false;
 CacheCost=0;
 MTU=0;
 data_send_counter=0;
 forwardingTable.clear();
 PendingCacheTable.clear();
 cachelist.clear();
 miss=0;
 hit=0;
 getnum=0;
 data_receive_counter=0;
 packetCounter_Bytes.clear();
 packetCounter_packets.clear();
 popularity.clear();
 reg_inter_num=0;
}

BRNode::~BRNode()
{
  cancelAndDelete(networkStates);
}

Define_Module(BRNode);

void BRNode::initialize(int stage)
{
    if(stage==0){
    nid_br = (uint32_t) par("nid");
    AS =  par("AS");
    MornitoringPeriod=par("MonitoringPeroid");

    EnableCache=par("EnableCache");

    cachespace=par("cachespace");
    CacheCost=par("CacheCost");
    avaliable_cache_space=cachespace;

    MTU=par("MTU");

    string rp = par("replacementPolicy");
    if(rp == "LRU") replacementPolicy=LRU;
    else if(rp=="LFU") replacementPolicy=LFU;
    else if(rp=="TTL") replacementPolicy=TTL;
    else if(rp=="RANDOM") replacementPolicy=RANDOM;
    else if(rp=="FIFO") replacementPolicy=FIFO;


    WATCH(nid_br);

    //获取网络拓扑，建立路由表

    char ASname[10];
    cTopology *topo=new cTopology("topo");
    topo->extractByParameter("AS",itoa(AS,ASname,10));     //通过AS号，来识别网络节点，并组织网络
    EV << "cTopology found" << topo->getNumNodes() << "nodes.\n";

    cTopology::Node *thisnode = topo->getNodeFor(this);

    //find and store next hops, using unweighted single shortest paths algorithms
    for (int i=0;i<topo->getNumNodes();i++)  //到达本域其他节点的最短路
    {
        if(topo->getNode(i)==thisnode) continue;
        topo->calculateUnweightedSingleShortestPathsTo(topo->getNode(i));
        if(thisnode->getNumPath()==0) continue; // This node is not connected

        cGate *gate =thisnode->getPath(0)->getLocalGate();
        int gateIndex=gate->getIndex();
        uint32_t nid= (uint32_t) topo->getNode(i)->getModule()->par("nid");
        int distance = (int) thisnode->getDistanceToTarget();
        forwardingTable[nid]=std::make_tuple(gateIndex,distance); //distance也存储带域内路由表中
        EV << "towards address " << nid <<  " gateIndex is " << gateIndex << " distance is " << distance <<endl;
    }
    delete topo;

    cModule * routingmodule = getParentModule()->getSubmodule("RoutingTable");
    RoutingTable * rt = dynamic_cast<RoutingTable*>(routingmodule);
    PATH_TABLE PT = rt->PathTable; //PID -> nid nid gate gate AS AS
    AS_TABLE  BRNTP = rt->BRNidToPids;//Nid -> pids
    PidsOnThisBR = BRNTP[nid_br];  //本NID的所有PID。
    std::map<uint32_t,uint32_t> ATR = rt->AStoRMnid;  // AS -> rm_nid
    RMNid = ATR[(uint32_t)AS];     //get local RM nid

    /**初始化几个0，不能是单纯的清空**/
    //int gateNum = gateSize("inter_port");
    //获取gate size,按照文章里的公式，只需要统计域间流量。建立端口到PID的映射。
    for(auto p : PidsOnThisBR)
    {
        packetCounter_Bytes[p]=0;
        packetCounter_packets[p]=0;
    }

    if(PidsOnThisBR.size()!=0){
    //FIXME:4月23日，BR有PID才发送感知给RM，这样也许不是很合理。
    networkStates = new cMessage("networkStates");  //汇报网络状态信息
    scheduleAt(simTime() + MornitoringPeriod, networkStates);
    }
    }//end stage==0
}

void BRNode::handleMessage(cMessage *msg)
{
    int outGateIndex;
    if(msg == networkStates)
    {   //selfmessage networkstates 让边界路路由器周期发送感知消息到RM
        char pakname[40];
        sprintf(pakname,"networkStates_BR_%d",nid_br);
        Mon * mon = new Mon(pakname);   //mornitoring.msg has not been built
        mon->setIsBR(true);
        mon->setKind(MORNITORING);
        mon->setNid(nid_br);
        mon->setDest(RMNid);

        //4月22，这里其实有点逻辑问题，下面的方式可以正常工作，前提是封装packetCounter时
        //默认按照PID从小到大的顺序封装。
        std::string data;
        //for(auto &here:packetCounter_packets)
        //{
        //    data += std::to_string(here.first)+":"+std::to_string(here.second)+",";
        //}
        for(auto m: PidsOnThisBR)
        {
            data += std::to_string(m) + ":" + std::to_string(packetCounter_Bytes[m])+":"+std::to_string(packetCounter_packets[m]) + ",";
        }
        data+=std::to_string(avaliable_cache_space);  //端口流量加缓存空间，以逗号分离
        mon->setData(data.c_str());
        outGateIndex = std::get<0>(forwardingTable[RMNid]); //forwardingTable加入了跳数
        EV<<"Forwarding network states packet "<<mon->getName() << "on gate index "<< outGateIndex <<endl;
        send(mon,"intra_port$o",outGateIndex);

        networkStates = new cMessage("networkStates");  //汇报网络状态信息
        scheduleAt(simTime() + MornitoringPeriod, networkStates); //要么delete，要么schedulaAt重新调度
    }
    else
    {
        short type = msg->getKind();
        if(type == GET)
        {
            const char * arrivedgate = msg->getArrivalGate()->getName();
            EV<<"Received a Get from " << arrivedgate <<endl;
            getnum++;

            Interest * interest= check_and_cast<Interest *>(msg);
            uint32_t sid = interest->getSid();
            uint32_t content_size = interest->getContent_size();
            uint32_t nid_client = interest->getNid_c();
            uint32_t nid_incoming = interest->getNid_incoming_br();
            uint32_t destAddr=interest->getNid_d();
            PIDs &pids = interest->getPid();  //数据包中pid序列的引用
            uint32_t last_pid;
            if(pids.size()!=0)
             last_pid = pids.back();  //尾部最后一个pid
            else
               {last_pid =0;
                EV<< "No Pid in the Interest." << endl;}

            if(nid_incoming==0)
            popularity[sid]+=1; //流行度条目+=1; 转发不加，只统计用户

            //域间的话，更新流量
            if(!strcmp(arrivedgate,"inter_port$i"))
            {
                packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + interest->getByteLength(); //域间流量更新
                packetCounter_packets[last_pid]=packetCounter_packets[last_pid] +1; //域间包数目+1
             }

            //查询本地缓存,cachelist,第三个字段存储的是某个内容的请求次数，可用于计算流行度。第二个字段存储内容大小
            if (EnableCache && cachespace!=0 && cachelist.size()!=0)
              {
               //查缓存
               CACHE_LIST::iterator it;
               bool cache_found_flag = false;
               for(it=cachelist.begin();it!=cachelist.end();++it)
                   {if(std::get<0>(*it) == sid){hit++;std::get<2>(*it)+=1;std::get<3>(*it)=simTime();break; EV<<"found content in local cache"<<endl;cache_found_flag=true;}
                    else {miss++;}}

               if(cache_found_flag)
                   {  //返回Data包，提取get包中的一些字段,PID判断,不能直接从入的端口返回，因为有可能BR和RM直连，Data包就会白传输到RM
                      //因此，需要对Data包里的字段正确的封装之后，在发到网络里，要么发往client，要么发往BR。
                      uint32_t newdestaddr;
                      if(last_pid==0)  //client在本域
                        {
                          newdestaddr = nid_client;
                          outGateIndex = std::get<0>(forwardingTable[nid_client]);
                        }
                      else
                        { //数据包返回到域间
                          //根据PID找对应的BR，根据BR找对应的出口。BR可能是自己，可能不是自己。是自己直接从PT中找端口，不是则从forwardingTable中找端口

                          uint32_t nidp1=std::get<0>(PT[last_pid]);
                          uint32_t nidp2=std::get<1>(PT[last_pid]);
                          if( nidp1 == nid_br)
                          {  newdestaddr=0; outGateIndex = std::get<2>(PT[last_pid]); pids.pop_back(); }// pid对应的BR是自己，返回data到域间，需要剥掉PID
                          else if(nidp2 == nid_br)
                          {   newdestaddr=0; outGateIndex = std::get<3>(PT[last_pid]); pids.pop_back();  }//pid对应的BR是自己，返回data到域间，需要剥掉PID
                          else
                          { //pid不是自己的，看哪个nid是本域可达的，然后哪个就是本域的节点
                              if(forwardingTable.count(nidp1)>0) {newdestaddr=nidp1;outGateIndex=std::get<0>(forwardingTable[nidp1]);}
                              else if(forwardingTable.count(nidp2)>0) {newdestaddr=nidp2;outGateIndex=std::get<0>(forwardingTable[nidp2]);}
                          }
                        }

                      //设置数据包长度的时候，直接用setByteLength即可。
                        Data * data = new Data;
                        data->setSid(sid);
                        data->setKind(DATA);
                        data->setContent_size(content_size);
                        data->setSerial_number(0);
                        data->setNid_d(newdestaddr); // 应该通过PID识别出口BR的NID。如果没有PID，则应该用nid_c,发给用户
                        data->setNid_c(nid_client); //客户端地址
                        data->setPid(pids); //没有取反向序列的PID

                        /*//下面两行没用
                        string str1 (MTU,'1'); // MTU 大小个1,注意1不能用""括，要用单''
                        data->setData(str1.c_str());
                        */

                       assert(MTU!=0);
                       int data_length = MTU -21 - pids.size()*4;
                       int number_of_data = content_size/data_length; //整数部分

                       for(int i=0;i<number_of_data;i++)
                       {
                          Data *copy=data->dup();
                          copy->setSerial_number(i+1);
                          copy->setByteLength(MTU);  //讲数据包长度设置为chunk_size+get包头
                          send(copy,outGateIndex);
                          packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + MTU;
                          packetCounter_packets[last_pid]=packetCounter_packets[last_pid] +1;
                          data_send_counter++;
                       }
                       size_t rest_length = (size_t) content_size%data_length;
                       if(rest_length != 0)
                       {
                          Data *copy_rest = data->dup();
                          //str1=string(content_size%chunk_size,'1');
                          //copy_rest->setData(str1.c_str());
                          copy_rest->setSerial_number(number_of_data+1);  //完整性校验
                          size_t rest_bytes_length= pids.size()*4+21+rest_length;
                          copy_rest->setByteLength(rest_bytes_length); //size_t可以直接给setByteLength赋值
                          send(copy_rest,outGateIndex);
                          packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid]+rest_bytes_length;
                          packetCounter_packets[last_pid]= packetCounter_packets[last_pid]+1;
                          data_send_counter++;
                       }
                       delete data;
                       delete interest; //删除请求包
                       return;
                    }
                }

            //判断请求包是域外来的，还是域内来的
            if(!strcmp(arrivedgate,"inter_port$i"))
            {//域间来的，之前没命中缓存，直接发往RM

                interest->setNid_incoming_br(nid_br);
                interest->setNid_d(RMNid); //修改目的地址
                std::map<uint32_t,std::tuple<int,int>>::iterator it=forwardingTable.find(RMNid);
                if(it!=forwardingTable.end())
                {
                    outGateIndex=std::get<0>((*it).second);
                    EV<<"Forwarding Interest "<< interest->getName() << "to RM on intra-domain gate" << outGateIndex <<endl;
                    send(interest,"intra_port$o",outGateIndex);
                    return;
                }
                else{
                    EV<<"RM is unreachable, discarding interest packet " << interest->getName() <<endl;
                    delete interest;
                    return;
                }
            }//域间发来的Get包
            else if(!strcmp(arrivedgate,"intra_port$i"))
            {//域内发来的get包，目的地址是自己，或者是RM，client发来的也是目的地址为RM
                if(destAddr==nid_br)
                {
                    //由于Data包的缓存，需要在Get包中添加一个cache_node的字段，用于表明RM选择的本域的缓存节点。
                    //如果边界路由器收到Get包，发现本字段不为0，则表明此服务需要在本域缓存。
                    if(interest->getCache_node()!=0)
                        PendingCacheTable[sid]=interest->getCache_node();  //存入带缓存条目

                    //目的地址是自己，则发往域间，提取本地RM添加的pid，发往域间
                    EV<<"Forwarding interest to inter-domain link " << last_pid <<endl;

                    interest->setCache_node(0); //缓存节点清空
                    interest->setNid_d(0);  //域内转发地址清空,与用户发来的没办法区分
                    interest->setNid_incoming_br(0); //接入地址清空

                    if(PT.count(last_pid)>0)  //FIXME:PT表条目多，查询时间长，用PidsOnThisBR来，速度会更快。第一次写的时候，没有设计第二个数据结构。
                    {
                        if(std::get<0>(PT[last_pid]) == nid_br)   //查PathTable 找到PID对应的端口
                            outGateIndex = std::get<2>(PT[last_pid]);
                        else if(std::get<1>(PT[last_pid])==nid_br)
                            outGateIndex = std::get<3>(PT[last_pid]);  // PT中查询端口号
                        else {delete interest; error("PID not found on this BR.");}  //如果PID不是本BR的PID。

                        EV<<"Forwarding interest " << interest->getName() << "to Remote BR on inter-domain gate " << outGateIndex << endl;
                        send(interest,"inter_port$o",outGateIndex); //发往域间

                        packetCounter_packets[last_pid] = packetCounter_packets[last_pid] + 1;
                        packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + interest->getByteLength();

                        return;
                    } //这个if其实可以没有
                    else error("RM Set a Wrong PID.");
                }
                else {
                    //目的地址不是自己，是域内其他节点，自己只是转发
                    if(nid_incoming == 0) interest->setNid_incoming_br(nid_br);//自己是client的接入路由器

                    if(forwardingTable.count(destAddr)>0)
                    {outGateIndex=std::get<0>(forwardingTable[destAddr]);
                    EV << "Forwarding interest to other node " << destAddr <<endl;
                    send(interest,"intra_port$o",outGateIndex); //发往目标节点
                    return;}
                    else error("DestAddr is unreachable.");
                }//end if destAddr != nid br
            }//域内发来的Get包
        }
        else if(type == DATA)
        {
            data_receive_counter++;
            const char * arrivedgate = msg->getArrivalGate()->getName();
            EV<<"Receivded a Data from " << arrivedgate <<endl;
            Data * data = check_and_cast <Data *> (msg);
            uint32_t sid = data->getSid();
            uint32_t content_size = data->getContent_size();
            int serial_number=data->getSerial_number();
            //uint32_t nid_client= data->getNid_c();
            bool if_cache = data->getNid_cache();
            uint32_t nid_dest = data->getNid_d();
            PIDs &PidInData = data->getPid();
            uint32_t last_pid;
            if(PidInData.size()>0)
            last_pid = PidInData.back(); //未删除的pid
            else
            last_pid = 0;

            if(!strcmp(arrivedgate,"inter_port$i")) //域间来的data包
            {
              //更新域间流量
               packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + data->getByteLength();
               packetCounter_packets[last_pid] = packetCounter_packets[last_pid] + 1;

               //删除pid
               PidInData.pop_back();
               data->setByteLength(data->getByteLength()-4); //调整域间来的data包的长度

               if(PidInData.size()>0)
                 last_pid = PidInData.back();
               else
                 last_pid = 0;
               //更新last_pid

              if(PendingCacheTable.count(sid)>0)  //需要缓存
              {
                  uint32_t newdest= PendingCacheTable[sid];

                  if(newdest == nid_br)
                  {
                      //缓存节点是自己,则就地缓存,缓存后自动发送注册消息和解注册消息
                      cache_content(serial_number,sid,content_size);
                      //查询PID,并转发, 发往对等BR
                      forward_data_according_to_pid(data,last_pid,outGateIndex);  //此函数发送时将data包中的Nid_cache字段清空，主要用于向域间转发，或者向客户转发。
                      return;
                  }
                  else{
                      // 缓存节点不是自己,更新目的地址并转发到缓存节点,待缓存表要删除
                      /*FIXME:待缓存列表不能在收到第一个内容分块的时候删除，需要等收到内容全部的分片后，再删除。
                                   未避免将同一个内容重复的传输到缓存节点,需要对PendingCacheTable进行修改，维护更多的条目,并不
                                   能单纯的以SID->NID的映射，进行缓存查询，可能需要是SID+client的形式。只用SID，必须保证
                                   内容在本域同一时间，只缓存一个副本。*/
                      if(serial_number== ceil(content_size/(double)MTU))
                      PendingCacheTable.erase(sid); //如果是最后一块内容，删除PendingCacheTable

                      data->setNid_d(newdest);
                      data->setNid_cache(true);
                      outGateIndex = std::get<0>(forwardingTable[newdest]);
                      EV << "Forwarding data to cache node "<< newdest <<endl;
                      send(data,"intra_port$o",outGateIndex); //发往缓存节点
                      return;
                      }
              }  // end if pendingCacheTable > 0
              else
              { //不需要缓存，判断尾部有没有PID，根据data包尾部的PID，发往PID对应的BR
                  forward_data_according_to_pid(data,last_pid,outGateIndex);
                  return;
              } // end else pendingCacheTable==0
            }// end if inter_port
            else if (!strcmp(arrivedgate,"intra_port$i")) //域内来的data包
            {//判断目的地址是不是自己,是自己则判断缓存还是转发，不是自己则转发。
                if(nid_dest==nid_br)
                {
                    if(if_cache)  cache_content(serial_number,sid,content_size); //如果需要缓存，则缓存，不需要缓存则直接执行后面的函数，发往域间client或者域内另一个节点。
                    forward_data_according_to_pid(data,last_pid,outGateIndex);  //不缓存，转发域间
                    return;
                }// end if nid_dest == nid_br
                else{
                    //根据目的地址转发，不需要修改报文字段
                    outGateIndex=std::get<0>(forwardingTable[nid_dest]);
                    send(data,"intra_port$o",outGateIndex);  //转发到另外的域内节点
                    return;
                }//end else nid != nid_br
            }
        }//end if type == DATA
        else if(type == REG)
        {
            //注册包，解注册包根据目的地址转发到RM，或者按照PID转发到域间，协商用。其中注册协商的开销需要单独测量。避免影响最后的域间流量调控效果
            //const char * arrivedgate = msg->getArrivalGate()->getName; //用nid_d就能判断目的地址
            Reg * regis = check_and_cast<Reg *>(msg);
            uint32_t destAddr = regis->getNid_d();
            PIDs & PidInReg = regis->getPid();
            uint32_t last_pid;
            if(PidInReg.size()>0)
            last_pid = PidInReg.back(); //未删除的pid
            else
            last_pid = 0;

            if(destAddr == 0 && last_pid!=0)
            {
                //域间来的注册包
                reg_inter_num++;
                regis->setNid_d(RMNid);
                //FIXME:查PT表的操作，应该重构成函数，能省去很多重复的操作
                uint32_t nidp1=std::get<0>(PT[last_pid]);
                uint32_t nidp2=std::get<1>(PT[last_pid]);
                uint32_t ASInReg;
                if(nidp1 == nid_br){ ASInReg=std::get<4>(PT[last_pid]);}
                if(nidp2 == nid_br){ ASInReg=std::get<5>(PT[last_pid]);}
                regis->setNid_s(ASInReg);  //填入AS号，且不需要删除尾部的PID
                outGateIndex = std::get<0>(forwardingTable[RMNid]);
                send(regis,"intra_port$o",outGateIndex);
                return;
            }
            else if (destAddr == nid_br)
            {
                //发给自己的，发往域间
                regis->setNid_s(AS); //源地址为本AS
                regis->setNid_d(0);  //域内转发地址清0
                uint32_t nidp1=std::get<0>(PT[last_pid]);
                uint32_t nidp2=std::get<1>(PT[last_pid]);
                if( nidp1 == nid_br){outGateIndex = std::get<2>(PT[last_pid]);send(regis,"inter_port$o",outGateIndex);return;}
                if( nidp2 == nid_br){outGateIndex = std::get<3>(PT[last_pid]);send(regis,"inter_port$o",outGateIndex);return;}
                return;
            }
            else {
                //域内来的（包括服务器，需要服务器直接填充目的地址为RM的NID），有目的地址，直接转发
                outGateIndex = std::get<0>(forwardingTable[destAddr]);
                send(regis,"intra_port$o",outGateIndex);
                return;
            }

            return;
        }
        else if(type == UNREG)
        {
            //解注册包，域间发来的，发给自己发往域间，转发到RM，或者转发,类似注册包的处理流程
            Unreg * unreg = check_and_cast<Unreg *>(msg);
            uint32_t destAddr = unreg->getNid_dest();

            if(destAddr == 0)
            {//域间发来的
                unreg->setNid_dest(RMNid);
                outGateIndex = std::get<0>(forwardingTable[RMNid]);
                send(unreg,"intra_port$o",outGateIndex);
                return;
            }
            else if(destAddr == nid_br)
            {//发给自己，发往域间
                PIDs & pids = unreg->getPid();
                uint32_t last_pid = pids.back();
                unreg->setNid_dest(0);  //域内转发地址清0
                unreg->setNid_source(AS); //域间传输填充AS号
                uint32_t nidp1=std::get<0>(PT[last_pid]);
                uint32_t nidp2=std::get<1>(PT[last_pid]);
                if( nidp1 == nid_br){outGateIndex = std::get<2>(PT[last_pid]);send(unreg,"inter_port$o",outGateIndex);}
                if( nidp2 == nid_br){outGateIndex = std::get<3>(PT[last_pid]);send(unreg,"inter_port$o",outGateIndex);}
                return;
            }
            else{//转发
                outGateIndex = std::get<0>(forwardingTable[destAddr]);
                send(unreg,"intra_port$o",outGateIndex);
                return;
            }
           return;
        }
        else if(type == MORNITORING )
        {//检测包直接发到RM
            outGateIndex = std::get<0>(forwardingTable[RMNid]);
            send(msg,"intra_port$o",outGateIndex);
            return;
        }
    }//不是self message 的检测消息
}

void BRNode::forward_data_according_to_pid(Data * data,uint32_t last_pid, int outGateIndex)
{
    if(last_pid!=0){//尾部有PID
       uint32_t nidp1=std::get<0>(PT[last_pid]);
       uint32_t nidp2=std::get<1>(PT[last_pid]);
       if( nidp1 == nid_br) //last_pid属于自己 FIXME:可以用4月22日添加的新数据结构PidsOnThisBR优化此部分程序，可以减少一个if
         { outGateIndex = std::get<2>(PT[last_pid]);

           data->setNid_d(0);  //发往域间，删除目的地址
           data->setNid_cache(false);
           send(data,"inter_port$o",outGateIndex);
           packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + data->getByteLength();
           packetCounter_packets[last_pid] = packetCounter_packets[last_pid] + 1;
           return;}// pid对应的BR是自己，返回data到域间，需要剥掉PID
       else if(nidp2 == nid_br) //last_pid属于自己
         { outGateIndex = std::get<3>(PT[last_pid]);

           data->setNid_d(0);
           data->setNid_cache(false);
           send(data,"inter_port$o",outGateIndex);
           packetCounter_Bytes[last_pid] = packetCounter_Bytes[last_pid] + data->getByteLength();
           packetCounter_packets[last_pid] = packetCounter_packets[last_pid] + 1;
           return;}//pid对应的BR是自己，返回data到域间，需要剥掉PID
       else
         { //pid不是自己的，看哪个nid是本域可达的，然后哪个就是本域的节点
            if(forwardingTable.count(nidp1)>0) {
                data->setNid_d(nidp1);
                data->setNid_cache(false);
                outGateIndex=std::get<0>(forwardingTable[nidp1]);
                send(data,"intra_port$o",outGateIndex);
                return;}
            else if(forwardingTable.count(nidp2)>0) {
                data->setNid_d(nidp2);
                data->setNid_cache(false);
                outGateIndex=std::get<0>(forwardingTable[nidp2]);
                send(data,"intra_port$o",outGateIndex);
                return;}
         }
      } // end if last_pid != 0
    else{
        //尾部没有PID
             uint32_t nid_client = data->getNid_c();
             data->setNid_d(nid_client);
             data->setNid_cache(false);
             outGateIndex = std::get<0>(forwardingTable[nid_client]);
             send(data,"intra_port$o",outGateIndex);
             return;
        } // end if last_pid == 0
}

void BRNode::cache_content(int serial_number,uint32_t sid, uint32_t content_size)
{
    //判断缓存满了没有
    //4月16日，需要添加注册的，缓存的内容是否需要域内注册
    if((uint32_t)avaliable_cache_space >= content_size)
    {//TODO:考虑按照内容块级别的缓存。目前是整个内容缓存在一个地方。需要维护更多的条目
        avaliable_cache_space = avaliable_cache_space - content_size;
        cachelist.push_back(std::forward_as_tuple(sid,content_size,0,simTime()));

        if(serial_number== ceil(content_size/(double)MTU))
        {
        PendingCacheTable.erase(sid); //如果是最后一块内容，删除PendingCacheTable

        send_registration(sid,content_size);
        //发送注册包到RM
        }
    }
    else{//运行缓存替换策略
         switch(replacementPolicy)
         {//以下几个策略考虑封装成函数
          case LRU:{
             EV<<"LRU replacement" <<endl;
             cachelist.sort([](auto &i, auto &j) -> bool {if(std::get<3>(i) > std::get<3>(j)) return true; else return false;}); //按照时间排序
             //按照内容大小更新缓存，可能要删除多个
             std::vector<uint32_t> sid_unreg;
             sid_unreg.clear();
             for(uint32_t counter=0;content_size>counter;)
             {
                 sid_unreg.push_back(std::get<0>(cachelist.back()));
                 uint32_t clear_cache_size = std::get<1>(cachelist.back());
                 cachelist.pop_back();
                 counter=counter+clear_cache_size;
             }//删到够用
             send_unregistration(sid_unreg);
             cachelist.push_back(std::forward_as_tuple(sid,content_size,0,simTime()));//存入新条目

             if(serial_number == ceil(content_size/(double)MTU)){
             PendingCacheTable.erase(sid); //如果是最后一块内容，删除PendingCacheTable
             //发注册包、解注册包到RM
             send_registration(sid,content_size);
             }
          }break;
          case LFU:{
              EV<<"LFU replacement"<<endl;
          }break;
          /*
          case TTL:
              EV<<"TTL replacement"<<endl;
              break;
          case "RANDOM:
              EV<<"Random replacement"<<endl;
              break;
          case FIFO:
              EV<<"FIFO replacement" <<endl;
              break;
          */
          default:
              error("Wrong replacement policy");
         }//end switch
    }// end else avaliable_cache_space < content_size
    return;
}

int BRNode::send_registration(uint32_t sid, uint32_t content_size)
{
  Reg * reg = new Reg;
  PIDs sizes;
  sizes.push_back(content_size);
  reg->setKind(REG);
  reg->setSid(sid);
  reg->setSid_from(0);
  reg->setSid_to(0);
  reg->setNid_s(nid_br);
  reg->setNid_d(RMNid);
  reg->setDistance(0);
  reg->setContent_size(sizes);
  //PID和link preference留空
  int outGate = std::get<0>(forwardingTable[RMNid]);
  reg->setByteLength(28); //7*4 + 0 + 0
  send(reg,"intra_port$o",outGate);
  return 0;
}

int BRNode::send_unregistration(std::vector<uint32_t> sid_unreg)
{
 Unreg * unreg = new Unreg;
 unreg->setKind(UNREG);
 unreg->setSid(sid_unreg);
 unreg->setNid_source(nid_br);
 unreg->setNid_dest(RMNid);
 //PID留空
 int outGate = std::get<0>(forwardingTable[RMNid]);
 unreg->setByteLength(sid_unreg.size()*4+8);//sid_unreg.size()*4 + 4*2 + 0 (pid.size()*4)
 send(unreg,"intra_port$o",outGate);
 return 0;
}

void BRNode::finish()
{
  //输出边界路由器的统计信息
  return;
}
