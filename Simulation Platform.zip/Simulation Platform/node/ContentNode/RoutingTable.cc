#include <omnetpp.h>
#include "RoutingTable.h"
#include <assert.h>

RoutingTable::RoutingTable()
{
    PathTable.clear();
    ASTable.clear();
    AStoRMnid.clear();
    content_sizes.clear();
    NumASes = 0;
    NumPids = 0;
    NumContents=0;
}

RoutingTable::~RoutingTable()
{
}

Define_Module(RoutingTable);

void RoutingTable::initialize(int stage)
{
    //initialize path table
        if(stage==0){
        NumContents=par("NumContents");

        std::vector<std::string> nedTypes;
        std::set<uint32_t> pidlist; //Ϊ����ASTable��ֵ������,ѭ��Ҫ��գ���Ȼ������
        std::set<uint32_t> aslist;
        bool flag;

        /*********Initialize Path Table and AS Table***********/
        nedTypes.push_back("node.ContentNode.BR_node");
        cTopology *topo = new cTopology("topo");

        topo->extractByNedTypeName(nedTypes);  //get topology all br_node
        EV<<"initializing routingTable, cTopology found"<<topo->getNumNodes()<<"nodes.\n";
        cTopology::Node * node;

        assert(topo->getNumNodes()>0);  //ȷ���ҵ��ı߽�·������Ŀ����0

        for(int i=0;i<topo->getNumNodes();i++)
        {
            node = topo->getNode(i);
            if(node->getNumOutLinks()==0) continue; //ȷ����ͨ�ԣ�����ڵ�û����ͨ��������
            else
            {
                for(int j=0;j<node->getNumOutLinks();j++)  //�����б߽�·����֮���·�����ж��ǲ������·��
                {
                    cTopology::Node *neighbor = node->getLinkOut(j)->getRemoteNode();
                    uint32_t asleft = (uint32_t) node->getModule()->par("AS");
                    uint32_t asright=(uint32_t) neighbor->getModule()->par("AS");
                    aslist.insert(asleft);  //aslist��set������洢�����ݲ����ظ���ͳ��AS�����д��ڵ�AS����
                    aslist.insert(asright);

                    //��ȡNID
                    uint32_t nidleft=(uint32_t) node->getModule()->par("nid");
                    uint32_t nidright=(uint32_t) neighbor->getModule()->par("nid"); //�ھӵ�nid

                    //��ȡ�˿ں�
                    int leftgate=node->getLinkOut(j)->getLocalGate()->getIndex();
                    int rightgate= node->getLinkOut(j)->getRemoteGate()->getIndex();

                    flag=true;

                    if(asleft == asright) continue; //AS����ȣ�·��Ϊ����·��
                    else {
                           EV<<"find inter-domain path from node: "<<node->getModule()->getFullName()<<" to "<<neighbor->getModule()->getFullName()<<endl;

                           if(!PathTable.empty()) //path table is not empty
                           {
                               for(auto &m:PathTable)
                                  {
                                   if(std::get<1>(m.second)==nidleft && std::get<0>(m.second)==nidright && std::get<3>(m.second)==leftgate && std::get<2>(m.second)==rightgate && std::get<5>(m.second)==asleft && std::get<4>(m.second)==asright) //������û��֮ǰ�������·��
                                   {
                                      flag=false; //�Ѿ����ڴ�PID
                                      break;
                                   }
                                  }
                           }    //��Ҫ�ж�����·����û�б����ӹ���flagΪtrue����,flagΪfalse����
                           if(flag==false) continue; //��������ѭ����ִ�к����PID����

                           NumPids++;
                           PathTable.insert({NumPids,std::forward_as_tuple(nidleft,nidright,leftgate,rightgate,asleft,asright)}); //fill PathTable, from PID to nids and gateIndex
                           pidlist.insert(NumPids);

                           //ASTable �и���valueֵ�������µ�PID
                           if(ASTable.count(asleft)>0) ASTable[asleft].insert(NumPids); //�Ѵ�����Ŀ������value
                           else ASTable.insert({asleft,pidlist}); //û�д�����Ŀ
                           if(ASTable.count(asright)>0) ASTable[asright].insert(NumPids);
                           else ASTable.insert({asright,pidlist});

                           if(BRNidToPids.count(nidleft)>0) BRNidToPids[nidleft].insert(NumPids); //������pid
                           else BRNidToPids.insert({nidleft,pidlist});
                           if(BRNidToPids.count(nidright)>0) BRNidToPids[nidright].insert(NumPids);
                           else BRNidToPids.insert({nidright,pidlist});
                           pidlist.clear(); //pidlist���
                    } //end asleft != asright
                }// end for getNumoutLinks
            } //end if getNumOutLinks !=0
        } //end for getNumNodes
        NumASes = aslist.size();
        EV<<"Found "<<NumASes<<" ASes "<<endl;
        EV<<"Found "<<NumPids<<" pids "<<endl;
        /********************end initialized path table and AS table***********************/


        /************initialize astormnid******************/
        nedTypes.clear();
        topo->clear();
        nedTypes.push_back("node.RM.RM");
        topo->extractByNedTypeName(nedTypes);
        EV<<"initializing AStoRMnid, cTopology found "<<topo->getNumNodes()<<" RM nodes.\n";
        assert(topo->getNumNodes()>0);

        for(int i=0;i<topo->getNumNodes();i++)
        {
            node = topo->getNode(i);
            uint32_t asid= (uint32_t) node->getModule()->par("AS");
            uint32_t rmnid= (uint32_t) node->getModule()->par("nid");
            AStoRMnid.insert({asid,rmnid});
        }//end for topo->getNumNodes()

        delete topo;

        for(int i=1;i<=NumContents;i++)
        {
            content_sizes[i] = ceil(geometric(0.02)*1000/8.0); //��ֵΪ50�ļ��ηֲ�����λΪMbits,*1000����8�����Bytes
            //content_sizes[i] = ceil(intuniform(10,1000)*1000/8.0); //10-1000�ľ��ȷֲ�����λMbits,*1000����8�����Bytes
        }
        EV<<"initialization content sizes for " << NumContents << "contents." <<endl;

        }//stage == 0
}
