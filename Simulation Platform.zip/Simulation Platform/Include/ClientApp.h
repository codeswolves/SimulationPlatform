#ifndef CLIENTAPP_H_
#define CLIENTAPP_H_
#include <omnetpp.h>
#include <random>
#include <vector>
#include <data_m.h>
#include <get_m.h>
#include <reg_m.h>
#include <algorithm>
#include <time.h>
#include <string>
#include <math.h>
#include <zipf.h>
#include <zipf_sampled.h>
#include <stdlib.h>
#include <assert.h>

class ClientApp : public cSimpleModule
{
  private:
    // configuration
    int nid_c;
    int AS;
    cPar *InterestsPerSecond;
    cPar *RateChangePeriod;
    cMessage *generatePacket;
    cMessage *ChangeInterestRate;
    cMessage *datapackets;
    long GetCounter;
    simtime_t packets_interval;
    double Zipf_alpha;
    int NumContent;    //the number of totoal content during the simualtion


    std::map<uint32_t,uint32_t> sizes;

  public:
    ClientApp();
    virtual ~ClientApp();
    bool is_active();
    bool is_ChangeRate();
    bool ChangeRate;  //�����Ƿ�ı䷢��Ƶ��
    bool Active;
    unsigned int zipf(double a, unsigned int n);

  protected:
    virtual int numInitStages() const  {return 2;}
    virtual void initialize(int stage);
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
};
#endif
