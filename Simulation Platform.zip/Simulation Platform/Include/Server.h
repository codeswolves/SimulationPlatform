#ifndef SERVER_H_
#define SERVER_H_
#include <omnetpp.h>
#include <random>
#include <vector>
#include <data_m.h>
#include <get_m.h>
#include <reg_m.h>
#include <algorithm>
#include <time.h>
#include <string>
#include <math.h>
#include <zipf.h>
#include <zipf_sampled.h>
#include <stdlib.h>
#include "RoutingTable.h"

typedef std::map<uint32_t,std::tuple<uint32_t,uint32_t,int,int,uint32_t,uint32_t>> PATH_TABLE;

class Server : public cSimpleModule
{
    private:
          uint32_t nid;
          uint32_t RMNid;
          uint32_t AS;  //AS of server

          std::map<uint32_t,uint32_t> sizes;  //��ʼ��ÿ�����ݵĴ�С

          std::vector<int> sidRange;
          bool Active;
          int NumContent;  //the number of content of simulation ��������
          long dataNum;
          long getNum;  //�յ���get����Ŀ
          int MTU;
          int reg_content_number;
          int from; //sid��ʼ
          int to;  //sid����
          PATH_TABLE PT;

    public:
          Server();
          virtual ~Server();
          bool is_active();

    protected:
          virtual int numInitStages() const  {return 2;}  //��ʱֻ���������׶εĳ�ʼ����
          virtual void initialize(int stage);
          virtual void handleMessages(cMessage *msg);
          virtual void finish();
};
#endif
