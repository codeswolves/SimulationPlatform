#ifndef __COLOR_H__
#define __COLOR_H__


typedef std::vector<uint32_t> PIDs;
typedef std::vector<double> LINKPREF;

enum msgType{
 GET = 1,
 DATA = 2,
 REG = 3,
 UNREG = 4,
 MORNITORING = 5
};
#endif
