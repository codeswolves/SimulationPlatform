//
// Generated file, do not edit! Created by nedtool 4.6 from packets/unreg.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "unreg_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(Unreg);

Unreg::Unreg(const char *name, int kind) : ::cPacket(name,kind)
{
    this->nid_source_var = 0;
    this->nid_dest_var = 0;
}

Unreg::Unreg(const Unreg& other) : ::cPacket(other)
{
    copy(other);
}

Unreg::~Unreg()
{
}

Unreg& Unreg::operator=(const Unreg& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void Unreg::copy(const Unreg& other)
{
    this->sid_var = other.sid_var;
    this->nid_source_var = other.nid_source_var;
    this->nid_dest_var = other.nid_dest_var;
    this->pid_var = other.pid_var;
}

void Unreg::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->sid_var);
    doPacking(b,this->nid_source_var);
    doPacking(b,this->nid_dest_var);
    doPacking(b,this->pid_var);
}

void Unreg::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->sid_var);
    doUnpacking(b,this->nid_source_var);
    doUnpacking(b,this->nid_dest_var);
    doUnpacking(b,this->pid_var);
}

PIDs& Unreg::getSid()
{
    return sid_var;
}

void Unreg::setSid(const PIDs& sid)
{
    this->sid_var = sid;
}

uint32_t Unreg::getNid_source() const
{
    return nid_source_var;
}

void Unreg::setNid_source(uint32_t nid_source)
{
    this->nid_source_var = nid_source;
}

uint32_t Unreg::getNid_dest() const
{
    return nid_dest_var;
}

void Unreg::setNid_dest(uint32_t nid_dest)
{
    this->nid_dest_var = nid_dest;
}

PIDs& Unreg::getPid()
{
    return pid_var;
}

void Unreg::setPid(const PIDs& pid)
{
    this->pid_var = pid;
}

class UnregDescriptor : public cClassDescriptor
{
  public:
    UnregDescriptor();
    virtual ~UnregDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(UnregDescriptor);

UnregDescriptor::UnregDescriptor() : cClassDescriptor("Unreg", "cPacket")
{
}

UnregDescriptor::~UnregDescriptor()
{
}

bool UnregDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Unreg *>(obj)!=NULL;
}

const char *UnregDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int UnregDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 4+basedesc->getFieldCount(object) : 4;
}

unsigned int UnregDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
    };
    return (field>=0 && field<4) ? fieldTypeFlags[field] : 0;
}

const char *UnregDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "sid",
        "nid_source",
        "nid_dest",
        "pid",
    };
    return (field>=0 && field<4) ? fieldNames[field] : NULL;
}

int UnregDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='s' && strcmp(fieldName, "sid")==0) return base+0;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_source")==0) return base+1;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_dest")==0) return base+2;
    if (fieldName[0]=='p' && strcmp(fieldName, "pid")==0) return base+3;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *UnregDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "PIDs",
        "uint32_t",
        "uint32_t",
        "PIDs",
    };
    return (field>=0 && field<4) ? fieldTypeStrings[field] : NULL;
}

const char *UnregDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int UnregDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Unreg *pp = (Unreg *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string UnregDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Unreg *pp = (Unreg *)object; (void)pp;
    switch (field) {
        case 0: {std::stringstream out; out << pp->getSid(); return out.str();}
        case 1: return ulong2string(pp->getNid_source());
        case 2: return ulong2string(pp->getNid_dest());
        case 3: {std::stringstream out; out << pp->getPid(); return out.str();}
        default: return "";
    }
}

bool UnregDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Unreg *pp = (Unreg *)object; (void)pp;
    switch (field) {
        case 1: pp->setNid_source(string2ulong(value)); return true;
        case 2: pp->setNid_dest(string2ulong(value)); return true;
        default: return false;
    }
}

const char *UnregDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0: return opp_typename(typeid(PIDs));
        case 3: return opp_typename(typeid(PIDs));
        default: return NULL;
    };
}

void *UnregDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Unreg *pp = (Unreg *)object; (void)pp;
    switch (field) {
        case 0: return (void *)(&pp->getSid()); break;
        case 3: return (void *)(&pp->getPid()); break;
        default: return NULL;
    }
}


