//
// Generated file, do not edit! Created by nedtool 4.6 from packets/get.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "get_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(Interest);

Interest::Interest(const char *name, int kind) : ::cPacket(name,kind)
{
    this->sid_var = 0;
    this->content_size_var = 0;
    this->nid_c_var = 0;
    this->nid_incoming_br_var = 0;
    this->nid_d_var = 0;
    this->cache_node_var = 0;
    this->QoS_level_var = 0;
}

Interest::Interest(const Interest& other) : ::cPacket(other)
{
    copy(other);
}

Interest::~Interest()
{
}

Interest& Interest::operator=(const Interest& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void Interest::copy(const Interest& other)
{
    this->sid_var = other.sid_var;
    this->content_size_var = other.content_size_var;
    this->nid_c_var = other.nid_c_var;
    this->nid_incoming_br_var = other.nid_incoming_br_var;
    this->nid_d_var = other.nid_d_var;
    this->cache_node_var = other.cache_node_var;
    this->QoS_level_var = other.QoS_level_var;
    this->pid_var = other.pid_var;
}

void Interest::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->sid_var);
    doPacking(b,this->content_size_var);
    doPacking(b,this->nid_c_var);
    doPacking(b,this->nid_incoming_br_var);
    doPacking(b,this->nid_d_var);
    doPacking(b,this->cache_node_var);
    doPacking(b,this->QoS_level_var);
    doPacking(b,this->pid_var);
}

void Interest::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->sid_var);
    doUnpacking(b,this->content_size_var);
    doUnpacking(b,this->nid_c_var);
    doUnpacking(b,this->nid_incoming_br_var);
    doUnpacking(b,this->nid_d_var);
    doUnpacking(b,this->cache_node_var);
    doUnpacking(b,this->QoS_level_var);
    doUnpacking(b,this->pid_var);
}

uint32_t Interest::getSid() const
{
    return sid_var;
}

void Interest::setSid(uint32_t sid)
{
    this->sid_var = sid;
}

uint32_t Interest::getContent_size() const
{
    return content_size_var;
}

void Interest::setContent_size(uint32_t content_size)
{
    this->content_size_var = content_size;
}

uint32_t Interest::getNid_c() const
{
    return nid_c_var;
}

void Interest::setNid_c(uint32_t nid_c)
{
    this->nid_c_var = nid_c;
}

uint32_t Interest::getNid_incoming_br() const
{
    return nid_incoming_br_var;
}

void Interest::setNid_incoming_br(uint32_t nid_incoming_br)
{
    this->nid_incoming_br_var = nid_incoming_br;
}

uint32_t Interest::getNid_d() const
{
    return nid_d_var;
}

void Interest::setNid_d(uint32_t nid_d)
{
    this->nid_d_var = nid_d;
}

uint32_t Interest::getCache_node() const
{
    return cache_node_var;
}

void Interest::setCache_node(uint32_t cache_node)
{
    this->cache_node_var = cache_node;
}

uint32_t Interest::getQoS_level() const
{
    return QoS_level_var;
}

void Interest::setQoS_level(uint32_t QoS_level)
{
    this->QoS_level_var = QoS_level;
}

PIDs& Interest::getPid()
{
    return pid_var;
}

void Interest::setPid(const PIDs& pid)
{
    this->pid_var = pid;
}

class InterestDescriptor : public cClassDescriptor
{
  public:
    InterestDescriptor();
    virtual ~InterestDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(InterestDescriptor);

InterestDescriptor::InterestDescriptor() : cClassDescriptor("Interest", "cPacket")
{
}

InterestDescriptor::~InterestDescriptor()
{
}

bool InterestDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Interest *>(obj)!=NULL;
}

const char *InterestDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int InterestDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 8+basedesc->getFieldCount(object) : 8;
}

unsigned int InterestDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
    };
    return (field>=0 && field<8) ? fieldTypeFlags[field] : 0;
}

const char *InterestDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "sid",
        "content_size",
        "nid_c",
        "nid_incoming_br",
        "nid_d",
        "cache_node",
        "QoS_level",
        "pid",
    };
    return (field>=0 && field<8) ? fieldNames[field] : NULL;
}

int InterestDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='s' && strcmp(fieldName, "sid")==0) return base+0;
    if (fieldName[0]=='c' && strcmp(fieldName, "content_size")==0) return base+1;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_c")==0) return base+2;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_incoming_br")==0) return base+3;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_d")==0) return base+4;
    if (fieldName[0]=='c' && strcmp(fieldName, "cache_node")==0) return base+5;
    if (fieldName[0]=='Q' && strcmp(fieldName, "QoS_level")==0) return base+6;
    if (fieldName[0]=='p' && strcmp(fieldName, "pid")==0) return base+7;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *InterestDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "uint32_t",
        "uint32_t",
        "uint32_t",
        "uint32_t",
        "uint32_t",
        "uint32_t",
        "uint32_t",
        "PIDs",
    };
    return (field>=0 && field<8) ? fieldTypeStrings[field] : NULL;
}

const char *InterestDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int InterestDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Interest *pp = (Interest *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string InterestDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Interest *pp = (Interest *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getSid());
        case 1: return ulong2string(pp->getContent_size());
        case 2: return ulong2string(pp->getNid_c());
        case 3: return ulong2string(pp->getNid_incoming_br());
        case 4: return ulong2string(pp->getNid_d());
        case 5: return ulong2string(pp->getCache_node());
        case 6: return ulong2string(pp->getQoS_level());
        case 7: {std::stringstream out; out << pp->getPid(); return out.str();}
        default: return "";
    }
}

bool InterestDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Interest *pp = (Interest *)object; (void)pp;
    switch (field) {
        case 0: pp->setSid(string2ulong(value)); return true;
        case 1: pp->setContent_size(string2ulong(value)); return true;
        case 2: pp->setNid_c(string2ulong(value)); return true;
        case 3: pp->setNid_incoming_br(string2ulong(value)); return true;
        case 4: pp->setNid_d(string2ulong(value)); return true;
        case 5: pp->setCache_node(string2ulong(value)); return true;
        case 6: pp->setQoS_level(string2ulong(value)); return true;
        default: return false;
    }
}

const char *InterestDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 7: return opp_typename(typeid(PIDs));
        default: return NULL;
    };
}

void *InterestDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Interest *pp = (Interest *)object; (void)pp;
    switch (field) {
        case 7: return (void *)(&pp->getPid()); break;
        default: return NULL;
    }
}


