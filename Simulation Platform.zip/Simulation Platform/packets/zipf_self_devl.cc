#include "zipf_self_devl.h"
#include <iostream>
#include <cmath>

using namespace std;

/*this function is used for initializing CDF of zipf.
 *
 *
 */


void gen_zipf_distribution::zipf_initialization()
{
   if (cdfzipf.size()!=0)
       return;
   double c=0;  //parameter of zipf
   double num=0;
   cout<<"Initializaing Zipf distribution of class #"<<class_num<<"..."<<endl;

   for (int i=1;i<=CN;i++)
   {
       c+=(1.0/pow(i+q,alpha)); //q��������Ϊ0
   }
   c = 1.0/c;

   normalization_constant = c;

   cout << "chosen percentile:\t" << agg << "\n";

   if(agg == 1.0) //the catalog is not aggregated.
   {
       cdfzipf.resize(CN+1);  //1 - CN
       cdfzipf[0]=-1;

       for(int i=1; i<=CN;i++)
       {
           num+=(1.0/ pow(i+q,alpha));
           cdfzipf[i] = num*c;
       }
   }
   else if (agg > 0 && agg < 1.0)
   {
       double temp =0 ;
       for (int i=1; i<=CN;i++)
       {
           num += (1.0/pow(i+q,alpha));
           temp=num*c;
           if(temp>=agg)
           {
               ID_agg=i;
               num=0;
               cout << "\nContent ID of correspondent to the chosen percentile:\t" << ID_agg << "\n";
               cdfzipf.resize(ID_agg+2); //��1Ӧ��Ҳ����
               cdfzipf[0]=-1; //0 is -1
               for (uint32_t j=1;j<=ID_agg+1;j++)//ID_agg�Ѿ�����agg�ˣ�ID_agg+1��Ȼ���ڡ�
               {
                   num+=(1.0/pow(j+q,alpha));
                   if(j<ID_agg+1)
                       cdfzipf[j] = num*c;
                   else
                       cdfzipf[j]=1;  //�ۻ��ĸ��� cdfzip�������µľۺ��Ժ��zipf����
               }
               cout << "size of the cdf vector:\t"<< cdfzipf.size() << "\n";
               cout << "last two values of the cdf:\t"<< cdfzipf[ID_agg+1]<<"\n";
               break;

           }
       }
   }
   else
   {
       cout<<"Insert a percentile value <1!";
   }
   cout << "zipf initialization completed"<< endl;
}


double gen_zipf_distribution::get_normalizaiton_constant()
{
    return normalization_constant;
}
unsigned int gen_zipf_distribution::get_ID_aggr()
{
    return ID_agg;
}
unsigned int gen_zipf_distribution::get_catalog_card()
{
    return CN;
}
double gen_zipf_distribution::get_perc_aggr()
{
    return agg;
}

unsigned int gen_zipf_distribution::value(double p)
{
    unsigned int upper, lower, atry, last_try;

    lower = -1;
    upper = cdfzipf.size()-1;
    atry = -1;
    last_try = -1;

    while(1)
    {
        atry = floor((lower+upper+1)/2);
        if(last_try==atry)
            break;
        if(cdfzipf[atry]>=p)
            upper=atry;
        else
            lower = atry-1;
        last_try = atry;
    }
    return upper;
}

double gen_zipf_distribution::get_alpha()
{
    return alpha;
}

