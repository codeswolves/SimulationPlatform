//
// Generated file, do not edit! Created by nedtool 4.6 from packets/data.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "data_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(Data);

Data::Data(const char *name, int kind) : ::cPacket(name,kind)
{
    this->sid_var = 0;
    this->content_size_var = 0;
    this->serial_number_var = 0;
    this->nid_d_var = 0;
    this->nid_c_var = 0;
    this->nid_cache_var = 0;
    this->data_var = "";
}

Data::Data(const Data& other) : ::cPacket(other)
{
    copy(other);
}

Data::~Data()
{
}

Data& Data::operator=(const Data& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void Data::copy(const Data& other)
{
    this->sid_var = other.sid_var;
    this->content_size_var = other.content_size_var;
    this->serial_number_var = other.serial_number_var;
    this->nid_d_var = other.nid_d_var;
    this->nid_c_var = other.nid_c_var;
    this->nid_cache_var = other.nid_cache_var;
    this->pid_var = other.pid_var;
    this->data_var = other.data_var;
}

void Data::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->sid_var);
    doPacking(b,this->content_size_var);
    doPacking(b,this->serial_number_var);
    doPacking(b,this->nid_d_var);
    doPacking(b,this->nid_c_var);
    doPacking(b,this->nid_cache_var);
    doPacking(b,this->pid_var);
    doPacking(b,this->data_var);
}

void Data::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->sid_var);
    doUnpacking(b,this->content_size_var);
    doUnpacking(b,this->serial_number_var);
    doUnpacking(b,this->nid_d_var);
    doUnpacking(b,this->nid_c_var);
    doUnpacking(b,this->nid_cache_var);
    doUnpacking(b,this->pid_var);
    doUnpacking(b,this->data_var);
}

uint32_t Data::getSid() const
{
    return sid_var;
}

void Data::setSid(uint32_t sid)
{
    this->sid_var = sid;
}

uint32_t Data::getContent_size() const
{
    return content_size_var;
}

void Data::setContent_size(uint32_t content_size)
{
    this->content_size_var = content_size;
}

int Data::getSerial_number() const
{
    return serial_number_var;
}

void Data::setSerial_number(int serial_number)
{
    this->serial_number_var = serial_number;
}

uint32_t Data::getNid_d() const
{
    return nid_d_var;
}

void Data::setNid_d(uint32_t nid_d)
{
    this->nid_d_var = nid_d;
}

uint32_t Data::getNid_c() const
{
    return nid_c_var;
}

void Data::setNid_c(uint32_t nid_c)
{
    this->nid_c_var = nid_c;
}

bool Data::getNid_cache() const
{
    return nid_cache_var;
}

void Data::setNid_cache(bool nid_cache)
{
    this->nid_cache_var = nid_cache;
}

PIDs& Data::getPid()
{
    return pid_var;
}

void Data::setPid(const PIDs& pid)
{
    this->pid_var = pid;
}

const char * Data::getData() const
{
    return data_var.c_str();
}

void Data::setData(const char * data)
{
    this->data_var = data;
}

class DataDescriptor : public cClassDescriptor
{
  public:
    DataDescriptor();
    virtual ~DataDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(DataDescriptor);

DataDescriptor::DataDescriptor() : cClassDescriptor("Data", "cPacket")
{
}

DataDescriptor::~DataDescriptor()
{
}

bool DataDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Data *>(obj)!=NULL;
}

const char *DataDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int DataDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 8+basedesc->getFieldCount(object) : 8;
}

unsigned int DataDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<8) ? fieldTypeFlags[field] : 0;
}

const char *DataDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "sid",
        "content_size",
        "serial_number",
        "nid_d",
        "nid_c",
        "nid_cache",
        "pid",
        "data",
    };
    return (field>=0 && field<8) ? fieldNames[field] : NULL;
}

int DataDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='s' && strcmp(fieldName, "sid")==0) return base+0;
    if (fieldName[0]=='c' && strcmp(fieldName, "content_size")==0) return base+1;
    if (fieldName[0]=='s' && strcmp(fieldName, "serial_number")==0) return base+2;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_d")==0) return base+3;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_c")==0) return base+4;
    if (fieldName[0]=='n' && strcmp(fieldName, "nid_cache")==0) return base+5;
    if (fieldName[0]=='p' && strcmp(fieldName, "pid")==0) return base+6;
    if (fieldName[0]=='d' && strcmp(fieldName, "data")==0) return base+7;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *DataDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "uint32_t",
        "uint32_t",
        "int",
        "uint32_t",
        "uint32_t",
        "bool",
        "PIDs",
        "string",
    };
    return (field>=0 && field<8) ? fieldTypeStrings[field] : NULL;
}

const char *DataDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int DataDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Data *pp = (Data *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string DataDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Data *pp = (Data *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getSid());
        case 1: return ulong2string(pp->getContent_size());
        case 2: return long2string(pp->getSerial_number());
        case 3: return ulong2string(pp->getNid_d());
        case 4: return ulong2string(pp->getNid_c());
        case 5: return bool2string(pp->getNid_cache());
        case 6: {std::stringstream out; out << pp->getPid(); return out.str();}
        case 7: return oppstring2string(pp->getData());
        default: return "";
    }
}

bool DataDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Data *pp = (Data *)object; (void)pp;
    switch (field) {
        case 0: pp->setSid(string2ulong(value)); return true;
        case 1: pp->setContent_size(string2ulong(value)); return true;
        case 2: pp->setSerial_number(string2long(value)); return true;
        case 3: pp->setNid_d(string2ulong(value)); return true;
        case 4: pp->setNid_c(string2ulong(value)); return true;
        case 5: pp->setNid_cache(string2bool(value)); return true;
        case 7: pp->setData((value)); return true;
        default: return false;
    }
}

const char *DataDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 6: return opp_typename(typeid(PIDs));
        default: return NULL;
    };
}

void *DataDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Data *pp = (Data *)object; (void)pp;
    switch (field) {
        case 6: return (void *)(&pp->getPid()); break;
        default: return NULL;
    }
}


