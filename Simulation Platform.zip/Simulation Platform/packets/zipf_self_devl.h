#ifndef ZIPF_SEFL_DEV_
#define ZIPF_SELF_DEV_
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

class gen_zipf_distribution{
    public:
      gen_zipf_distribution(double alpha, int ContentNum):alpha(alpha),CN(ContentNum){;};
      gen_zipf_distribution(double alpha, double p, int ContentNum):alpha(alpha),q(p),CN(ContentNum){;};

      //�ۺϺ��zipf�ֲ����������ض�����ʹ��zipf,k�Ǿۺ�����,����������Ĳ�ͬ��Ҫ��ʼ����ͬ���������жȵķֲ���
      gen_zipf_distribution(double a, double p, int ContentNum, double k):alpha(a),q(p),CN(ContentNum),agg(k){;};
      //gen_zipf_distribution(double a, double p, int ContentNum, double k,int AS_N):alpha(a),q(p),CN(ConteneNum),agg(k),ASN(AS_N){;};
      gen_zipf_distribution(){gen_zipf_distribution(0,0);}
      void zipf_initialization();
      int zipf_gen_rng();

      unsigned int value (double p);
      //return the index of the content y such that the sum of the
      //probabilities of contents from 0 to y is >=p
      double get_normalizaiton_constant();
      unsigned int get_ID_aggr();
      unsigned int get_catalog_card();
      double get_perc_aggr();
      double get_alpha();

    private:
      vector<double> cdfzipf;
      double alpha;
      double q; //
      int CN; //content number
      double agg;
      unsigned int ID_agg; //content id associated to the specified percentile for the catalog aggregation
      int class_num=1; //class number to which the zipf distribution is referred. Default is 1;
      double normalization_constant;
};
#endif
